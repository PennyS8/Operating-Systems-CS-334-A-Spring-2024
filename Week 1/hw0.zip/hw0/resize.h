#ifndef RESIZE_H
#define RESIZE_H

typedef struct point{
	int x_cor;
	int y_cor;
	int color;
}point;

void resize(point***, int*);

#endif